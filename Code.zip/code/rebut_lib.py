"""Shared evaluation harness for the ICLR 2027 rebuttal experiments.

Paper and rebuttal evaluation harness with fixed Pro-GNN/LCC splits, packaged graph inputs, explicit seeds, per-run logging, and explicit feature modes.
"""
import os
import sys
import json
import time
import hashlib
import contextlib
import io
import numpy as np
import scipy.sparse as sp
import torch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from load_datasets.dataset2 import Dataset  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
TMP1 = os.path.join(ROOT, 'data', 'official') + os.sep
CACHE = os.path.join(ROOT, 'results', 'cache')
os.makedirs(CACHE, exist_ok=True)


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


@contextlib.contextmanager
def quiet():
    with contextlib.redirect_stdout(io.StringIO()):
        yield


NOFEAT = os.path.join(ROOT, 'data', 'nofeat', 'graph{}') + os.sep
PROGNN_META = os.path.join(ROOT, 'data', 'official') + os.sep
# official Pro-GNN splits (github.com/ChandlerBang/Pro-GNN/splits) + Pro-GNN Metattack graphs + DICE graphs
OFFICIAL = os.path.join(ROOT, 'data', 'official') + os.sep


def graph_root(source, idx=0):
    """Return a package-local data root. 'nofeat' selects one of 10 paper-protocol graph sets."""
    if source == 'tmp1':
        return TMP1
    if source == 'nofeat':
        return NOFEAT.format(idx % 10 + 1)
    if source == 'prognn':
        return PROGNN_META
    if source == 'official':
        return OFFICIAL
    if source == 'gen':
        return OFFICIAL
    raise ValueError(source)


def load_clean(name, root=TMP1):
    """name may be '<dataset>_rw<r>' for a degree-preserving rewired copy of <dataset>."""
    base = name.split('_rw')[0]
    if not os.path.exists(os.path.join(root, f'{base}.npz')):
        root = TMP1
    with quiet():
        d = Dataset(root=root, name=base, setting='prognn')
    if '_rw' in name:
        d.adj = sp.load_npz(os.path.join(OFFICIAL, f'{name}_clean_adj.npz')).tocsr()
    return d


def get_features(d, mode):
    n = d.adj.shape[0]
    if mode == 'identity':
        return sp.eye(n, format='csr', dtype=np.float32)
    if mode == 'standard':
        return sp.csr_matrix(d.features).astype(np.float32)
    raise ValueError(mode)


def attacked_path(name, attack, rate, root=TMP1):
    return os.path.join(root, f'{name}_{attack}_adj_{rate}.npz')


def load_attacked(d, name, attack, rate, root=TMP1):
    if float(rate) == 0.0:
        A = d.adj
    else:
        A = sp.load_npz(attacked_path(name, attack, rate, root))
    A = sp.csr_matrix(A).astype(np.float64)
    A.data[:] = 1.0
    A.eliminate_zeros()
    return A


FEAT_ATTACKS = ('metax', 'metaax')   # z11_gen_featatk.py: attacks that also perturb the node features


def load_attacked_features(X, name, attack, rate, root=TMP1):
    """Perturbed features for the feature attacks (unchanged X for the edge-only attacks).
    Rate 0 of a feature attack: the clean features, binarised (X > 0) if they are continuous (Cora-ML), because the
    attack flips bits of the binarised matrix -- so 0% and the attacked rates use the same feature space."""
    if attack not in FEAT_ATTACKS:
        return X
    if float(rate) == 0.0:
        X = sp.csr_matrix(X).astype(np.float32)
        if not np.all(np.isin(X.data, [0, 1])):
            X = (X > 0).astype(np.float32)
        return X
    return sp.load_npz(os.path.join(root, f'{name}_{attack}_x_{rate}.npz')).tocsr().astype(np.float32)


def cache_file(tag):
    return os.path.join(CACHE, hashlib.md5(tag.encode()).hexdigest()[:16] + '.npz')


def cached(tag, fn):
    """Cache deterministic purification results (EquiliRes / pruning) as sparse npz."""
    f = cache_file(tag)
    if os.path.exists(f):
        return sp.load_npz(f)
    t0 = time.time()
    M = sp.csr_matrix(fn())
    tmp = f'{f}.{os.getpid()}.tmp.npz'
    sp.save_npz(tmp, M)
    os.replace(tmp, f)
    with open(f + '.json', 'w') as fh:
        json.dump(dict(tag=tag, seconds=time.time() - t0), fh)
    return M


def train_gcn(features, adj, labels, idx_train, idx_val, idx_test, seed, device,
              hidden=16, dropout=0.5, lr=0.01, weight_decay=5e-4, epochs=200):
    from deeprobust.graph.defense import GCN
    set_seed(seed)
    model = GCN(nfeat=features.shape[1], nhid=hidden, nclass=int(labels.max()) + 1,
                dropout=dropout, lr=lr, weight_decay=weight_decay, device=device).to(device)
    with quiet():
        model.fit(features, adj, labels, idx_train, idx_val, train_iters=epochs, verbose=False)
        model.eval()
        acc = model.test(idx_test)
    return float(acc)


def train_gcn_full(features, adj, labels, idx_train, idx_val, idx_test, seed, device,
                   hidden=16, dropout=0.5, lr=0.01, weight_decay=5e-4, epochs=None):
    """Same as train_gcn but also returns the validation accuracy (for model/budget selection)."""
    from deeprobust.graph.defense import GCN
    if epochs is None:   # RE_EPOCHS: training epochs (default 200 as in the paper)
        epochs = int(os.environ.get('RE_EPOCHS', '200'))
    set_seed(seed)
    model = GCN(nfeat=features.shape[1], nhid=hidden, nclass=int(labels.max()) + 1,
                dropout=dropout, lr=lr, weight_decay=weight_decay, device=device).to(device)
    with quiet():
        model.fit(features, adj, labels, idx_train, idx_val, train_iters=epochs, verbose=False)
        model.eval()
        out = model.predict().argmax(1).cpu().numpy()
    return dict(acc=float((out[idx_test] == labels[idx_test]).mean()),
                val=float((out[idx_val] == labels[idx_val]).mean()))


def append_jsonl(path, rec):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'a') as fh:
        fh.write(json.dumps(rec) + '\n')


def summarize(path, keys=('dataset', 'attack', 'rate', 'method', 'features')):
    import pandas as pd
    df = pd.read_json(path, lines=True)
    g = df.groupby(list(keys))['acc']
    out = g.agg(['mean', 'std', 'count', 'min', 'max']).reset_index()
    out['mean'] *= 100
    out['std'] = g.apply(lambda s: np.std(s, ddof=0) * 100).values
    out['min'] *= 100
    out['max'] *= 100
    return out
