"""Fast re-implementation of EquiliRes (Alg. 1 + Alg. 2) that reproduces the original
dense implementations edge-for-edge.

Original code paths reproduced here:
  * variant='jul' : defenses/One{GAT,HANG,MidGCN}/all3.py  (stop when (1-p) of the
                    similarity list remains; an edge is removed only if beta increases)
  * variant='nov' : defenses/EquiliRes/all3.py              (stop when (1-p)/3 remains;
                    a rejected edge is still removed together with the next one)
  * variant='julsafe' (rebuttal): 'jul' that never removes the last edge of a node
  * variant='auto'  : hao_code/Code6.1/defense/examples/auto/all3.py (2024-11), see _equilires_auto

Key observations used for speed:
  * similarities never change during the loop, so repeatedly popping the minimum of the
    dict == walking the list sorted (stably) by similarity in insertion order
    (lexicographic (i<j) order of `itertools.combinations`);
  * compute_metrics(A) only depends on in/out degrees:
        x = sum_k in_k*out_k / sum_k out_k,
        y = 4 * sum_k out_k*(in_k+out_k)/(N-1) / sum_k out_k
    so it can be updated in O(1) per edge flip.
"""
import numpy as np
import scipy.sparse as sp


def two_hop_sets(A):
    """Binary CSR matrix B with B[i, j] = 1 iff j is within 2 hops of i (j != i)."""
    A = sp.csr_matrix(A)
    A = (A != 0).astype(np.float32)
    B = (A + A @ A).tocsr()
    B.sum_duplicates()
    B = (B - sp.diags(B.diagonal(), format='csr')).tocsr()   # drop self (csr.setdiag is unsafe here)
    B.eliminate_zeros()
    B.data[:] = 1
    B = B.astype(np.int8)
    B.sort_indices()
    return B


def edge_list_lex(A):
    """Edges (i<j) with A[i, j] != 0, in lexicographic order (== combinations order)."""
    T = sp.triu(sp.csr_matrix(A), k=1).tocsr()
    T.eliminate_zeros()
    T.sort_indices()
    rows = np.repeat(np.arange(T.shape[0]), np.diff(T.indptr))
    cols = T.indices.copy()
    return rows.astype(np.int64), cols.astype(np.int64)


def two_hop_jaccard(A, rows, cols, batch=20000):
    B = two_hop_sets(A)
    size = np.asarray(B.sum(1)).ravel().astype(np.int64)
    inter = np.empty(len(rows), dtype=np.int64)
    for s in range(0, len(rows), batch):
        r, c = rows[s:s + batch], cols[s:s + batch]
        inter[s:s + batch] = np.asarray(B[r].multiply(B[c]).sum(1)).ravel()
    union = size[rows] + size[cols] - inter
    sim = np.zeros(len(rows), dtype=np.float64)
    nz = union > 0
    sim[nz] = inter[nz].astype(np.float64) / union[nz].astype(np.float64)
    return sim


class _DegreeState:
    """Tracks in/out degrees of a (possibly asymmetric) 0/1 matrix and the two metrics."""

    def __init__(self, A):
        A = sp.csr_matrix(A)
        self.N = A.shape[0]
        self.present = set(zip(*[x.tolist() for x in A.nonzero()]))
        self.out = np.asarray((A != 0).sum(1)).ravel().astype(np.int64)
        self.inn = np.asarray((A != 0).sum(0)).ravel().astype(np.int64)
        self.s_out = int(self.out.sum())
        self.s_io = int((self.inn * self.out).sum())
        self.s_oio = int((self.out * (self.inn + self.out)).sum())

    def metrics_after_removing(self, entries):
        """Metrics if the directed entries in `entries` (all present) were removed."""
        out, inn = dict(), dict()
        for (i, j) in entries:
            out[i] = out.get(i, 0) + 1
            inn[j] = inn.get(j, 0) + 1
        s_out, s_io, s_oio = self.s_out, self.s_io, self.s_oio
        for k in set(out) | set(inn):
            o0, i0 = int(self.out[k]), int(self.inn[k])
            o1, i1 = o0 - out.get(k, 0), i0 - inn.get(k, 0)
            s_out += o1 - o0
            s_io += i1 * o1 - i0 * o0
            s_oio += o1 * (i1 + o1) - o0 * (i0 + o0)
        if s_out == 0:
            return 0.0, 0.0
        x = s_io / s_out
        y = 4.0 * (s_oio / (self.N - 1)) / s_out
        return x, y

    def remove(self, entries):
        for (i, j) in entries:
            if (i, j) not in self.present:
                continue
            self.present.discard((i, j))
            self._apply(i, j)

    def _apply(self, i, j):
        for k, do, di in ((i, 1, 0), (j, 0, 1)):
            o0, i0 = int(self.out[k]), int(self.inn[k])
            o1, i1 = o0 - do, i0 - di
            self.s_out += o1 - o0
            self.s_io += i1 * o1 - i0 * o0
            self.s_oio += o1 * (i1 + o1) - o0 * (i0 + o0)
            self.out[k], self.inn[k] = o1, i1


def _equilires_auto(A, i_pct, sim=None, return_info=False, safe=False, floor=None):
    """Variant 'auto' = hao_code/Code6.1/defense/examples/auto/all3.py (2024-11; the code whose output
    is printed in the notes of auto/test_svd2.py and matches Table 1 of the submission):
      * pops ONE edge per iteration (lowest 2-hop Jaccard first, ties in lexicographic order),
      * removes it from a copy of best_A and keeps it only if x and y both increase (x_tmp = y_tmp = 0 at the start),
      * stops when the number of remaining similarity entries <= initial * i_pct / 100 (i_pct is a *retained* percentage),
      * the model is trained on `modified_A` = best_A minus the last popped edge (even if that last removal was rejected).
    `i_pct` is chosen by the caller (the original script grid-searches it on the TEST accuracy).
    floor (rebuttal, two-sided variant): a removal is also accepted when beta~ after the removal stays
    >= floor, so edges whose removal lowers beta~ can be removed as long as the graph stays on or above
    the reference equilibrium coordinate ('start' = beta~ of the input graph)."""
    A = sp.csr_matrix(A).astype(np.float64)
    assert np.all(A.data == 1), 'expects a 0/1 adjacency'
    rows, cols = edge_list_lex(A)
    if sim is None:
        sim = two_hop_jaccard(A, rows, cols)
    order = np.argsort(sim, kind='stable')
    L0 = len(order)
    st = _DegreeState(A)
    x_tmp, y_tmp = 0.0, 0.0
    if floor == 'start':
        floor = st.metrics_after_removing([])[0]
    t, accepted, last = 0, 0, None
    while t < L0:
        e = order[t]; t += 1
        i, j = int(rows[e]), int(cols[e])
        ent = [(i, j), (j, i)]
        x, y = st.metrics_after_removing(ent)
        if safe and min(st.out[i], st.out[j]) <= 1:   # 'autosafe': never take the last edge of a node
            x, y = -1.0, -1.0
        if (x > x_tmp and y > y_tmp) or (floor is not None and x >= floor):
            x_tmp, y_tmp = x, y
            st.remove(ent)
            accepted += 1
            last = None
        else:
            last = ent
        if (L0 - t) <= L0 * i_pct / 100:
            break
    if last is not None and not safe:
        st.remove(last)
    keep = np.array(sorted(st.present), dtype=np.int64).reshape(-1, 2)
    out = sp.csr_matrix((np.ones(len(keep)), (keep[:, 0], keep[:, 1])), shape=A.shape)
    if return_info:
        n_rem = (L0 * 2 - len(keep)) // 2 if len(keep) else L0
        return out, dict(n_edges=L0, iters=t, accepted=accepted, removed=int(L0 - len(keep) // 2), removed_frac=(L0 - len(keep) // 2) / max(L0, 1),
                         beta=x_tmp, x=y_tmp)
    return out


def equilires(A, budget, variant='jul', sim=None, return_info=False, ref=None):
    """Run EquiliRes edge modification. `budget` plays the role of `ptbrate` in the
    original code. Returns the purified adjacency (scipy CSR, same values as original).
    Two-sided variants (rebuttal): 'bi' = 'auto' with floor beta~(input graph); 'bio' = 'auto' with
    floor `ref` (beta~ of the clean graph, i.e. the paper's "Original" point)."""
    if variant in ('auto', 'autosafe', 'bi', 'bisafe', 'bio'):   # budget = scanned fraction = 1 - i_pct/100
        if variant == 'bio' and ref is None:
            raise ValueError("variant 'bio' needs ref = beta~ of the clean graph")
        floor = {'bi': 'start', 'bisafe': 'start', 'bio': ref}.get(variant)   # 'bisafe' (v13): two-sided + never the last edge of a node
        return _equilires_auto(A, round(100.0 * (1.0 - budget), 6), sim=sim, return_info=return_info,
                               safe=variant in ('autosafe', 'bisafe'), floor=floor)
    A = sp.csr_matrix(A).astype(np.float64)
    assert np.all(A.data == 1), 'expects a 0/1 adjacency'
    rows, cols = edge_list_lex(A)
    if sim is None:
        sim = two_hop_jaccard(A, rows, cols)
    order = np.argsort(sim, kind='stable')
    n_init = len(order)
    safe = variant == 'julsafe'   # 'jul' + never remove the last edge of a node (no isolated nodes)
    if variant in ('jul', 'julsafe'):
        stop_at = n_init * (1 - budget)
    elif variant == 'nov':
        stop_at = n_init * ((1 - budget) / 3)
    else:
        raise ValueError(variant)

    st = _DegreeState(A)
    x_tmp, y_tmp = 0.0, 0.0
    ptr, removed, accepted, iters = 0, [], 0, 0
    while True:
        iters += 1
        e1 = order[ptr]; ptr += 1
        i, j = int(rows[e1]), int(cols[e1])
        e1_entries = [(i, j), (j, i)] if ((i, j) in st.present and (j, i) in st.present) else []
        # modify_matrix pops the next minimum (crashes in the original if the list is empty)
        e2 = order[ptr]; ptr += 1
        p, q = int(rows[e2]), int(cols[e2])
        x, y = st.metrics_after_removing(e1_entries)
        if safe and e1_entries and min(st.out[i], st.out[j]) <= 1:
            x, y = -1.0, -1.0   # reject
        if x > x_tmp and y > y_tmp:
            x_tmp, y_tmp = x, y
            st.remove(e1_entries)
            removed.extend([(i, j)] if e1_entries else [])
            accepted += 1
        else:
            if variant == 'nov':
                # best_A already had e1 removed, plus e2 removed unconditionally
                st.remove(e1_entries)
                e2_entries = [e for e in ((p, q), (q, p)) if e in st.present]
                st.remove(e2_entries)
                removed.extend([(i, j)] if e1_entries else [])
                removed.extend([(p, q)] if e2_entries else [])
        if (n_init - ptr) <= stop_at:
            break

    keep = np.array(sorted(st.present), dtype=np.int64).reshape(-1, 2)
    out = sp.csr_matrix((np.ones(len(keep)), (keep[:, 0], keep[:, 1])), shape=A.shape)
    if return_info:
        info = dict(n_edges=n_init, iters=iters, accepted=accepted, removed=len(removed),
                    removed_frac=len(removed) / max(n_init, 1), beta=x_tmp, x=y_tmp)
        return out, info
    return out


def struct_jaccard_prune(A, n_remove, sim=None):
    """Ablation: remove the n_remove lowest 2-hop-Jaccard edges, no acceptance rule."""
    A = sp.csr_matrix(A).astype(np.float64)
    rows, cols = edge_list_lex(A)
    if sim is None:
        sim = two_hop_jaccard(A, rows, cols)
    order = np.argsort(sim, kind='stable')[:n_remove]
    M = A.tolil()
    for e in order:
        M[rows[e], cols[e]] = 0
        M[cols[e], rows[e]] = 0
    M = M.tocsr()
    M.eliminate_zeros()
    return M


def postprocess(adj, dense=False):
    """Same post-processing as EquiliRes/gcn_central2.py::GCNSVD.purify_adj.
    dense=False returns the equivalent sparse matrix without the 1e-6 self-weights of isolated
    nodes (deeprobust's sparse GCN path adds I anyway, so the normalised adjacency is identical
    up to 1e-6)."""
    if not dense:
        M = sp.csr_matrix(adj).astype(np.float64)
        M = ((M + M.T) * 0.5).tocsr()
        M = (M - sp.diags(M.diagonal())).tocsr()
        M.eliminate_zeros()
        return M
    M = np.array(adj.toarray() if sp.issparse(adj) else adj, dtype=np.float64, copy=True)
    M = 0.5 * (M + M.T)
    M[M < 0] = 0.0
    np.fill_diagonal(M, 0.0)
    deg = M.sum(1)
    iso = np.where(deg <= 1e-8)[0]
    M[iso, iso] = 1e-6
    return M


# ---------------------------------------------------------------------------
# Scalable 2-hop Jaccard (numba, parallel over source nodes) for large graphs
# such as ogbn-arxiv. Gives exactly the same similarities as two_hop_jaccard.
# ---------------------------------------------------------------------------
def two_hop_jaccard_numba(A, rows, cols, n_threads=32):
    import numba as nb
    from numba import njit, prange
    nb.set_num_threads(n_threads)
    B = two_hop_sets(A)
    indptr, indices = B.indptr.astype(np.int64), B.indices.astype(np.int32)
    size = np.diff(indptr)
    N = A.shape[0]
    # group edges by source row (rows are sorted because of lexicographic order)
    starts = np.searchsorted(rows, np.arange(N + 1)).astype(np.int64)

    @njit(parallel=True, cache=False)
    def _inter(indptr, indices, starts, cols, n_threads, N):
        out = np.zeros(len(cols), dtype=np.int64)
        marks = np.zeros((n_threads, N), dtype=np.bool_)
        chunk = (N + n_threads - 1) // n_threads
        for t in prange(n_threads):
            mk = marks[t]
            for u in range(t * chunk, min(N, (t + 1) * chunk)):
                if starts[u] == starts[u + 1]:
                    continue
                for p in range(indptr[u], indptr[u + 1]):
                    mk[indices[p]] = True
                for e in range(starts[u], starts[u + 1]):
                    v = cols[e]
                    c = 0
                    for p in range(indptr[v], indptr[v + 1]):
                        if mk[indices[p]]:
                            c += 1
                    out[e] = c
                for p in range(indptr[u], indptr[u + 1]):
                    mk[indices[p]] = False
        return out

    inter = _inter(indptr, indices, starts, cols.astype(np.int64), n_threads, N)
    union = size[rows] + size[cols] - inter
    sim = np.zeros(len(rows), dtype=np.float64)
    nz = union > 0
    sim[nz] = inter[nz].astype(np.float64) / union[nz].astype(np.float64)
    return sim
