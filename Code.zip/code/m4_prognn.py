"""M4: Pro-GNN (Jin et al., KDD'20) via deeprobust, official hyper-parameters from
github.com/ChandlerBang/Pro-GNN/scripts/meta/*.sh, official splits + Pro-GNN Metattack graphs.

  python m4_prognn.py --dataset cora --rates 0 0.05 0.1 --seeds 0 1 --device cuda:0
  --pre equ_jul_b0.15   runs Pro-GNN on the EquiliRes-purified graph (method 'equ_jul_b0.15+prognn')
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace
import numpy as np
import scipy.sparse as sp
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rebut_lib import OFFICIAL, ROOT, load_clean, load_attacked, set_seed, quiet, append_jsonl  # noqa: E402

HP = {'cora': dict(alpha=5e-4, beta=1.5, gamma=1, lambda_=1e-3),
      'citeseer': dict(alpha=5e-4, beta=1.5, gamma=1, lambda_=1e-4),
      'polblogs': dict(alpha=1e-4, beta=5, gamma=1, lambda_=0),
      'cora_ml': dict(alpha=5e-4, beta=1.5, gamma=1, lambda_=1e-3)}
OUT = os.environ.get('M4_OUT', os.path.join(ROOT, 'results', 'm4_prognn.jsonl'))   # z11 feature attacks: separate file


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--attack', default='meta')
    ap.add_argument('--rates', nargs='+', type=float, default=[0, 0.05, 0.1, 0.15, 0.2, 0.25])
    ap.add_argument('--seeds', nargs='+', type=int, default=[0])
    ap.add_argument('--epochs', type=int, default=1000)
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--pre', default=None, help='EquiliRes purification before Pro-GNN, e.g. equ_jul_b0.15')
    ap.add_argument('--source', default='official', choices=['official', 'nofeat'],
                    help="nofeat (v12): protocol of the submission, identity features, seed s uses attacked graph ~/defense/noFeature/tmp{s+1}")
    a = ap.parse_args()
    if a.source == 'nofeat':
        assert len(a.seeds) == 1, 'nofeat: one seed (= one attacked graph) per process'
    method = 'prognn' if a.pre is None else f'{a.pre}+prognn'
    from deeprobust.graph.defense import GCN, ProGNN
    if os.environ.get('M4_GPU_PROX') == '1':   # v13: nuclear-norm proximal step on the GPU (deeprobust's prox_nuclear_cuda, same operator;
        from deeprobust.graph.defense.pgd import prox_operators   # the CPU SVD takes ~30 s per epoch on the loaded server, the GPU one ~0.6 s)
        prox_operators.prox_nuclear = prox_operators.prox_nuclear_cuda
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT):
            q = json.loads(l); done.add((q['dataset'], q['attack'], q['rate'], q.get('method', 'prognn'), q['seed']))
    from rebut_lib import graph_root
    root = OFFICIAL if a.source == 'official' else graph_root('nofeat', a.seeds[0])
    gtag = 'prognn' if a.source == 'official' else f'nofeat{a.seeds[0] % 10 + 1}'
    d = load_clean(a.dataset, root)
    X = torch.FloatTensor(np.asarray(sp.csr_matrix(d.features).todense())) if a.source == 'official' else torch.eye(d.adj.shape[0])
    y = torch.LongTensor(d.labels)
    X0 = X
    from rebut_lib import FEAT_ATTACKS, load_attacked_features
    for r in a.rates:
        A = load_attacked(d, a.dataset, a.attack, r, root)
        X = X0   # feature attacks (z11_gen_featatk.py): perturbed features
        if a.attack in FEAT_ATTACKS:
            X = torch.FloatTensor(np.asarray(load_attacked_features(sp.csr_matrix(d.features), a.dataset, a.attack,
                                                                    r, OFFICIAL).todense()))
        if a.pre is not None:
            from rebut_lib import cached
            from equilires_fast import equilires
            _, v, b = a.pre.split('_'); b = float(b[1:])
            A = cached(f'equ|{a.dataset}|{a.attack}|{r}|{v}|{b}|{gtag}', lambda: equilires(A, b, variant=v))
        At = torch.FloatTensor(np.asarray(A.todense()))
        for seed in a.seeds:
            if (a.dataset, a.attack, r, method, seed) in done:
                continue
            set_seed(seed)
            args = SimpleNamespace(debug=False, only_gcn=False, lr=5e-4, weight_decay=5e-4, hidden=16, dropout=0.5,
                                   epochs=a.epochs, phi=0, inner_steps=2, outer_steps=1, lr_adj=0.01,
                                   symmetric=False, **HP[a.dataset])
            t = time.time()
            model = GCN(nfeat=X.shape[1], nhid=16, nclass=int(y.max()) + 1, dropout=0.5, device=a.device)
            pg = ProGNN(model, args, a.device)
            with quiet():   # official train.py moves all tensors to the device first
                pg.fit(X.to(a.device), At.to(a.device), y.to(a.device), d.idx_train, d.idx_val)
                pg.model.eval()
                adj = pg.best_graph
                if pg.best_graph is None:
                    adj = pg.estimator.normalize()
                out = pg.model(X.to(a.device), adj).argmax(1).cpu().numpy()
            acc = float((out[d.idx_test] == d.labels[d.idx_test]).mean())
            val = float((out[d.idx_val] == d.labels[d.idx_val]).mean())
            append_jsonl(OUT, dict(dataset=a.dataset, attack=a.attack, rate=r, method=method,
                                   features='standard' if a.source == 'official' else 'identity', source=a.source, graph=gtag,
                                   seed=seed, acc=acc, val=val, seconds=time.time() - t,
                                   epochs=a.epochs))
            print(a.dataset, r, seed, acc, f'{time.time() - t:.0f}s', flush=True)
            del pg, model
            torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
