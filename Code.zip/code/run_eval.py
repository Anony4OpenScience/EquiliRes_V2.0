"""Generic poisoning evaluation: purify (optional) -> train GCN -> test, per seed.

Example:
  python run_eval.py --datasets citeseer --attacks meta --rates 0 0.05 0.1 \
      --methods gcn equ_jul equ_nov --features identity standard --seeds 10 \
      --out results/t0_repro.jsonl --workers 8
Method names:
  gcn                 plain GCN on the attacked graph
  equ_<v>             EquiliRes variant v in {jul,nov}, budget = attack rate (original code)
  equ_<v>_b<B>        EquiliRes with fixed budget B (e.g. equ_jul_b0.1)
  sjac_<v>            structural (2-hop) Jaccard pruning removing the same #edges as equ_<v>
  svd_k<K>            GCN-SVD rank K (deeprobust)
  jac_t<T>            GCN-Jaccard threshold T (deeprobust, needs features)
  gnnguard            GNNGuard (port of official implementation)
"""
import argparse
import itertools
import os
import sys
import time
import traceback
import multiprocessing as mp

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def purified_adj(d, name, attack, rate, method, A, gtag='tmp1', post=True):
    """Structure purification. post=True applies the paper's post-processing (dense, used
    when the downstream model is the paper's GCN); post=False returns the 0/1 CSR graph."""
    from rebut_lib import cached
    from equilires_fast import equilires, struct_jaccard_prune, postprocess
    parts = method.split('_')
    g = '' if gtag == 'tmp1' else f'|{gtag}'
    v = parts[1]
    budget = float(parts[2][1:]) if len(parts) > 2 else float(rate)
    ref = None
    if v == 'bio':   # two-sided variant anchored at the clean graph's equilibrium coordinate
        import numpy as np
        deg = np.asarray((sp_csr(d.adj) != 0).sum(1)).ravel().astype(np.float64)
        ref = float((deg * deg).sum() / deg.sum())
    P_equ = cached(f'equ|{name}|{attack}|{rate}|{v}|{budget}' + g,
                   lambda: equilires(A, budget, variant=v, ref=ref))
    if parts[0] == 'equ':
        P = P_equ
    elif parts[0] == 'sjac':
        n_remove = int((A.nnz - P_equ.nnz) // 2)
        P = cached(f'sjac|{name}|{attack}|{rate}|{n_remove}' + g,
                   lambda: struct_jaccard_prune(A, n_remove))
    else:
        raise ValueError(method)
    return postprocess(P) if post else P


def sp_csr(M):
    import scipy.sparse as sp
    return sp.csr_matrix(M)


def split_method(method):
    """'equ_jul' -> ('equ_jul', 'gcn'); 'equ_jul+rung' -> ('equ_jul', 'rung'); 'rung' -> (None, 'rung')."""
    if '+' in method:
        pur, model = method.split('+', 1)
        return pur, model
    if method.startswith(('equ_', 'sjac_')):
        return method, 'gcn'
    return None, method


def _dr_eval(m, labels, idx_val, idx_test):
    out = m.predict().argmax(1).cpu().numpy()
    return dict(acc=float((out[idx_test] == labels[idx_test]).mean()),
                val=float((out[idx_val] == labels[idx_val]).mean()))


def _fix_svd_norm():
    """v16 (2026-11-15): the rank-k reconstruction of GCN-SVD can have rows with sum(A_k + I) <= 0; deeprobust's
    normalize_adj_tensor then gives D^-1/2 = NaN (it only zeroes inf), every logit becomes NaN and argmax predicts class 0
    for all nodes (e.g. 5.45% = share of class 0 in the Citeseer test set). Zero D^-1/2 for non-positive degrees, as deeprobust
    already does for zero degrees; the output is unchanged whenever all degrees are positive."""
    import torch
    from deeprobust.graph import utils as U
    if getattr(U.normalize_adj_tensor, '_v16', False):
        return
    orig = U.normalize_adj_tensor

    def fixed(adj, sparse=False):
        if sparse:
            return orig(adj, sparse=True)
        mx = adj + torch.eye(adj.shape[0]).to(adj.device)
        rowsum = mx.sum(1).flatten()
        r_inv = rowsum.pow(-1 / 2)
        r_inv[~(rowsum > 0)] = 0.
        r_mat_inv = torch.diag(r_inv)
        return r_mat_inv @ mx @ r_mat_inv
    fixed._v16 = True
    U.normalize_adj_tensor = fixed


def run_model(model, X, A, labels, d, seed, device):
    import numpy as np
    from rebut_lib import train_gcn_full, set_seed, quiet
    if model == 'gcn':
        return train_gcn_full(X, A, labels, d.idx_train, d.idx_val, d.idx_test, seed, device)
    if model.startswith('svd_k'):
        from deeprobust.graph.defense import GCNSVD
        _fix_svd_norm()
        set_seed(seed)
        m = GCNSVD(nfeat=X.shape[1], nhid=16, nclass=int(labels.max()) + 1, device=device).to(device)
        with quiet():
            m.fit(X, A, labels, d.idx_train, d.idx_val, k=int(model[5:]), verbose=False,
                  train_iters=int(os.environ.get('RE_EPOCHS', '200')))
            m.eval()
            return _dr_eval(m, labels, d.idx_val, d.idx_test)
    if model.startswith('jac_t'):
        from deeprobust.graph.defense import GCNJaccard
        set_seed(seed)
        binary = bool(np.all(np.isin(X.data, [0, 1])))
        m = GCNJaccard(nfeat=X.shape[1], nhid=16, nclass=int(labels.max()) + 1,
                       binary_feature=binary, device=device).to(device)
        with quiet():
            m.fit(X, A, labels, d.idx_train, d.idx_val, threshold=float(model[5:]), verbose=False,
                  train_iters=int(os.environ.get('RE_EPOCHS', '200')))
            m.eval()
            return _dr_eval(m, labels, d.idx_val, d.idx_test)
    if model == 'gnnguard':
        from gnnguard import run_gnnguard
        return run_gnnguard(X, A, labels, d.idx_train, d.idx_val, d.idx_test, seed, device)
    if model == 'gnnguard_s':     # v12: structural similarity (no node features)
        from gnnguard import run_gnnguard
        return run_gnnguard(X, A, labels, d.idx_train, d.idx_val, d.idx_test, seed, device, struct=True)
    if model == 'rung':
        from rung_wrap import run_rung
        return run_rung(X, A, labels, d.idx_train, d.idx_val, d.idx_test, seed, device)
    raise ValueError(model)


def run_model_safe(model, X, A, labels, d, seed, device):
    """run_model on `device`; falls back to CPU when the (shared) GPU is out of memory."""
    import torch
    if device != 'cpu':
        try:
            return run_model(model, X, A, labels, d, seed, device)
        except (torch.cuda.OutOfMemoryError, RuntimeError) as e:
            if 'out of memory' not in str(e):
                raise
            torch.cuda.empty_cache()
    return run_model(model, X, A, labels, d, seed, 'cpu')


def run_job(job):
    import torch
    from rebut_lib import load_clean, get_features, load_attacked, append_jsonl, graph_root
    name, attack, rate, method, feat, seeds, out, device = job[:8]
    source = job[8] if len(job) > 8 else 'tmp1'
    done = job[9] if len(job) > 9 else set()
    torch.set_num_threads(int(os.environ.get('RE_THREADS', '2')))
    pur, model = split_method(method)
    try:
        t0 = time.time()
        loaded = False
        for idx, seed in enumerate(seeds):
            if seed in done:
                continue
            if not loaded or source == 'nofeat':
                loaded = True
                root = graph_root(source, idx)
                gtag = 'tmp1' if source == 'tmp1' else f'{source}{idx % 10 + 1 if source == "nofeat" else ""}'
                if source == 'official':   # same graphs as 'prognn' (meta) / 'tmp1' (dice): reuse purification cache
                    gtag = 'prognn' if attack == 'meta' else 'tmp1'
                d = load_clean(name, root)
                if attack.startswith('ntk'):   # targeted attacks (x4_nettack.py): accuracy on the target nodes
                    import numpy as np
                    d.idx_test = np.load(os.path.join(root, f'{name}_{attack}_targets.npy'))
                labels = d.labels
                X = get_features(d, feat)
                if feat == 'standard':
                    from rebut_lib import load_attacked_features
                    X = load_attacked_features(X, name, attack, rate, root)
                A = load_attacked(d, name, attack, rate, root)
                if pur is not None:
                    M = purified_adj(d, name, attack, rate, pur, A, gtag, post=(model == 'gcn'))
                else:
                    M = A
            t1 = time.time()
            dev = device
            if model not in ('rung', 'gnnguard', 'gnnguard_s') and M.shape[0] < 5000 and os.environ.get('RE_CPU', '1') == '1':
                dev = 'cpu'
            if model not in ('rung', 'gnnguard', 'gnnguard_s') and os.environ.get('RE_FORCE_CPU') == '1':
                dev = 'cpu'
            r = run_model_safe(model, X, M, labels, d, seed, dev)
            append_jsonl(out, dict(dataset=name, attack=attack, rate=float(rate), method=method,
                                   features=feat, seed=seed, acc=r['acc'], val=r.get('val'),
                                   seconds=time.time() - t1, source=source, graph=gtag))
        return f'ok {name} {attack} {rate} {method} {feat} {source} ({time.time() - t0:.0f}s)'
    except Exception:
        return f'FAIL {name} {attack} {rate} {method} {feat} {source}\n' + traceback.format_exc()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--datasets', nargs='+', required=True)
    ap.add_argument('--attacks', nargs='+', default=['meta'])
    ap.add_argument('--rates', nargs='+', default=['0', '0.05', '0.1', '0.15', '0.2', '0.25'])
    ap.add_argument('--methods', nargs='+', required=True)
    ap.add_argument('--features', nargs='+', default=['identity'])
    ap.add_argument('--seeds', type=int, default=10)
    ap.add_argument('--seed0', type=int, default=0)
    ap.add_argument('--out', required=True)
    ap.add_argument('--workers', type=int, default=4)
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--source', default='tmp1', choices=['tmp1', 'nofeat', 'prognn', 'gen', 'official'])
    a = ap.parse_args()
    seeds = list(range(a.seed0, a.seed0 + a.seeds))
    finished = {}
    if os.path.exists(a.out):
        import json
        for line in open(a.out):
            r = json.loads(line)
            k = (r['dataset'], r['attack'], float(r['rate']), r['method'], r['features'], r.get('source', 'tmp1'))
            finished.setdefault(k, set()).add(r['seed'])
    jobs = []
    for n, atk, r, m, f in itertools.product(a.datasets, a.attacks, a.rates, a.methods, a.features):
        done = finished.get((n, atk, float(r), m, f, a.source), set())
        if set(seeds) <= done:
            continue
        jobs.append((n, atk, r, m, f, seeds, a.out, a.device, a.source, done))
    print(f'{len(jobs)} jobs to run', flush=True)
    # purification jobs first so that the slow ones start early
    jobs.sort(key=lambda j: (not j[3].startswith(('equ', 'sjac')), j[0] != 'photo'))
    ctx = mp.get_context('spawn')
    with ctx.Pool(a.workers, maxtasksperchild=1) as pool:
        for msg in pool.imap_unordered(run_job, jobs):
            print(msg, flush=True)


if __name__ == '__main__':
    main()
