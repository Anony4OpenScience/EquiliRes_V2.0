"""M2: adaptive (defense-aware) poisoning attack against EquiliRes.

EquiliRes removes a candidate edge (u, v) only if the removal increases beta~ (and x~, which is
8 beta~/(N-1) on undirected graphs). For an undirected graph beta~ = sum(d^2)/sum(d), so the
removal is accepted iff d_u + d_v - 1 < beta~ (independent of the similarity ranking and of the
pruning budget). An attacker who knows the rule therefore only inserts edges whose endpoints
(degrees d before the insertion) satisfy d_u + d_v + 1 >= beta~ + margin: EquiliRes rejects their
removal whatever budget the defender selects, unless it first lowers the endpoint degrees by
removing other edges. Deletions are unrestricted (EquiliRes never adds edges).

Rule-aware Meta-Self (Metattack, lambda=0, same surrogate/hyper-parameters as Pro-GNN) with this
constraint applied to the meta-gradient score at every greedy step; the flip order is recorded so
one run up to the largest budget yields all smaller budgets (greedy prefix).

  python m2_adaptive.py --dataset cora --features standard --device cuda:0
Output: data/prognn_official/{ds}_ameta_adj_{r}.npz (+ _flips.npy with the ordered flip list)
"""
import argparse
import json
import os
import sys
import time
import numpy as np
import scipy.sparse as sp
import torch
from tqdm import tqdm

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rebut_lib import OFFICIAL, ROOT, load_clean, get_features, set_seed, quiet, append_jsonl  # noqa: E402
from deeprobust.graph.global_attack import Metattack  # noqa: E402
from deeprobust.graph import utils  # noqa: E402

RATES = [0.05, 0.1, 0.15, 0.2, 0.25]


def post_insertion_jaccard(A):
    """Dense symmetric 0/1 tensor A -> (J_new, J_cur). J_new[u, v] = 2-hop Jaccard of the pair (u, v) in
    A + {(u, v)} (definition of equilires_fast.two_hop_jaccard: 2-hop sets without the node itself),
    valid for non-edges; J_cur[u, v] = 2-hop Jaccard in A, used for the current edges.
    With S = 2-hop indicator, after inserting (u, v): S'_u = S_u + N[v], S'_v = S_v + N[u], so
    |S'_u & S'_v| = |S_u & S_v| + d_u + d_v - |N(u) & S_v| - |S_u & N(v)| and
    |S'_u | S'_v| = |S_u | S_v| + 2 * [dist(u, v) > 2]."""
    S = ((A + A @ A) > 0).float()
    S.fill_diagonal_(0)
    s, d = S.sum(1), A.sum(1)
    SS = S @ S
    AS = A @ S
    inter = SS - AS - AS.T + d[:, None] + d[None, :]
    union = s[:, None] + s[None, :] - SS + 2 * (1 - S)
    J_new = inter / union.clamp(min=1)
    J_cur = SS / (s[:, None] + s[None, :] - SS).clamp(min=1)
    return J_new, J_cur


class RuleAwareMetattack(Metattack):
    def __init__(self, *a, margin=1.0, rule=True, jac_q=None, **kw):
        super().__init__(*a, **kw)
        self.margin, self.rule, self.jac_q = margin, rule, jac_q

    def get_adj_score(self, adj_grad, modified_adj, ori_adj, ll_constraint, ll_cutoff):
        s = super().get_adj_score(adj_grad, modified_adj, ori_adj, ll_constraint, ll_cutoff)
        if self.jac_q is not None:   # similarity-aware: only insert pairs that land outside the lowest jac_q of the ranking
            A = modified_adj.detach()
            J_new, J_cur = post_insertion_jaccard(A)
            tau = torch.quantile(J_cur[torch.triu(A, 1) > 0], self.jac_q)
            return s * ((J_new > tau) | (A > 0)).float()
        if not self.rule:
            return s
        d = modified_adj.sum(1)
        beta = (d * d).sum() / d.sum()
        protected = (d[:, None] + d[None, :] + 1.0) >= beta + self.margin
        return s * (protected | (modified_adj > 0)).float()

    def attack_ordered(self, ori_features, ori_adj, labels, idx_train, idx_unlabeled, n_perturbations, on_step=None,
                       init_flips=None):
        """Same loop as Metattack.attack (structure only, no ll constraint) but records the flips.
        init_flips: greedy prefix of an interrupted run (re-applied, then the greedy loop continues)."""
        self.sparse_features = sp.issparse(ori_features)
        ori_adj, ori_features, labels = utils.to_tensor(ori_adj, ori_features, labels, device=self.device)
        labels_self_training = self.self_training_label(labels, idx_train)
        flips = [] if init_flips is None else [tuple(int(v) for v in f) for f in init_flips]
        for r, c, dl in flips:
            self.adj_changes.data[r][c] += dl
            self.adj_changes.data[c][r] += dl
        for _ in tqdm(range(n_perturbations - len(flips)), mininterval=60):
            modified_adj = self.get_modified_adj(ori_adj)
            adj_norm = utils.normalize_adj_tensor(modified_adj)
            self.inner_train(ori_features, adj_norm, idx_train, idx_unlabeled, labels)
            adj_grad, _ = self.get_meta_grad(ori_features, adj_norm, idx_train, idx_unlabeled, labels, labels_self_training)
            score = self.get_adj_score(adj_grad, modified_adj, ori_adj, False, 0.004)
            r, c = utils.unravel_index(torch.argmax(score), ori_adj.shape)
            delta = -2 * modified_adj[r][c] + 1
            self.adj_changes.data[r][c] += delta
            self.adj_changes.data[c][r] += delta
            flips.append((int(r), int(c), int(delta.item())))
            if on_step is not None:
                on_step(np.array(flips, dtype=np.int64))
        return np.array(flips, dtype=np.int64)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True)
    ap.add_argument('--features', default='standard')
    ap.add_argument('--margin', type=float, default=1.0)
    ap.add_argument('--tag', default='ameta')
    ap.add_argument('--no_rule', action='store_true', help='plain Meta-Self (control, same code path)')
    ap.add_argument('--jac_q', type=float, default=None,
                    help='similarity-aware attack against the two-sided variant: only insert pairs whose post-insertion '
                         '2-hop Jaccard exceeds the jac_q-quantile of the current edges (replaces the degree rule)')
    ap.add_argument('--max_rate', type=float, default=0.25)
    ap.add_argument('--seed', type=int, default=15)
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--fresh', action='store_true', help='ignore the checkpoint of an interrupted run')
    a = ap.parse_args()
    from deeprobust.graph.defense import GCN
    d = load_clean(a.dataset, OFFICIAL)
    A = sp.csr_matrix(d.adj).astype(np.float32)
    X = get_features(d, a.features)
    if a.dataset == 'polblogs' or a.features == 'identity':
        X = sp.eye(A.shape[0], format='csr', dtype=np.float32)
    E = int(A.sum() // 2)
    n_max = int(a.max_rate * E)
    set_seed(a.seed)
    idx_unlabeled = np.union1d(d.idx_val, d.idx_test)
    sur = GCN(nfeat=X.shape[1], nclass=int(d.labels.max()) + 1, nhid=16, dropout=0, with_relu=False,
              with_bias=False, device=a.device).to(a.device)
    with quiet():
        sur.fit(X, A, d.labels, d.idx_train, d.idx_val, patience=30)
    atk = RuleAwareMetattack(sur, nnodes=A.shape[0], feature_shape=X.shape, attack_structure=True,
                             attack_features=False, device=a.device, lambda_=0, margin=a.margin,
                             rule=not a.no_rule and a.jac_q is None, jac_q=a.jac_q).to(a.device)
    t = time.time()
    targets = {int(r * E): r for r in RATES if int(r * E) <= n_max}

    ckpt = os.path.join(OFFICIAL, f'{a.dataset}_{a.tag}_ckpt.npy')
    init = None
    if not a.fresh:   # resume an interrupted run (shared GPUs: CUDA OOM restarts via retry.sh)
        for p in [ckpt, os.path.join(OFFICIAL, f'{a.dataset}_{a.tag}_flips.npy')]:
            if os.path.exists(p):
                x = np.load(p)
                if len(x) <= n_max and (init is None or len(x) > len(init)):
                    init = x
        if init is not None:
            print(f'resuming from {len(init)} flips', flush=True)

    def save(flips):   # write each budget as soon as the greedy prefix reaches it
        n = len(flips)
        if n % 20 == 0:
            np.save(ckpt, flips)
        if n not in targets:
            return
        r = targets[n]
        np.save(os.path.join(OFFICIAL, f'{a.dataset}_{a.tag}_flips.npy'), flips)
        M = A.tolil()
        for i, j, dl in flips:
            M[i, j] = M[i, j] + dl; M[j, i] = M[j, i] + dl
        M = sp.csr_matrix(M); M.eliminate_zeros()
        sp.save_npz(os.path.join(OFFICIAL, f'{a.dataset}_{a.tag}_adj_{r}.npz'), M)
        ins = int((flips[:, 2] > 0).sum())
        append_jsonl(os.path.join(ROOT, 'results', 'm2_attack_stats.jsonl'),
                     dict(dataset=a.dataset, tag=a.tag, rate=r, n=n, inserted=ins, removed=n - ins,
                          margin=a.margin, rule=not a.no_rule and a.jac_q is None, jac_q=a.jac_q, seconds=time.time() - t))
        print(f'{a.dataset} {a.tag} {r}: {n} flips ({ins} insertions), {time.time() - t:.0f}s', flush=True)

    atk.attack_ordered(X, A, d.labels, d.idx_train, idx_unlabeled, n_max, on_step=save, init_flips=init)
    if os.path.exists(ckpt):
        os.remove(ckpt)


if __name__ == '__main__':
    main()
