"""z13 (2026-11-18): how does the ASEP criterion act on the attacked graph?  Paper protocol (no features), Metattack.
For each attacked graph: share of inserted (adversarial) edges among the removed edges (precision) vs their share in the graph,
recall, and edge homophily of clean / attacked / EquiliRes / same-count plain 2-hop Jaccard graphs.  Labels are used for diagnosis only.
Usage: python z13_mech_homophily.py <dataset> [n_graphs] [b]"""
import sys, os, json, numpy as np, scipy.sparse as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rebut_lib import load_clean, load_attacked, graph_root
from equilires_fast import equilires, struct_jaccard_prune, edge_list_lex, two_hop_jaccard

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results', 'z13_mech_homophily.jsonl')


def eset(M):
    M = sp.csr_matrix(M); r, c = M.nonzero()
    return set((int(a), int(b)) for a, b in zip(r, c) if a < b)


def homo(E, y):
    E = np.array(sorted(E))
    return float((y[E[:, 0]] == y[E[:, 1]]).mean())


def beta(E, n):
    d = np.zeros(n)
    for a, b in E:
        d[a] += 1; d[b] += 1
    return float((d * d).sum() / d.sum())


name = sys.argv[1]; n_graphs = int(sys.argv[2]) if len(sys.argv) > 2 else 3; b = float(sys.argv[3]) if len(sys.argv) > 3 else 0.5
for idx in range(n_graphs):
    root = graph_root('nofeat', idx)
    d = load_clean(name, root); y = np.asarray(d.labels); n = len(y)
    C = eset(d.adj)
    for rate in ('0.05', '0.15', '0.25'):
        A = load_attacked(d, name, 'meta', rate, root)
        EA = eset(A); ins = EA - C
        rows, cols = edge_list_lex(A); sim = two_hop_jaccard(A, rows, cols)
        P = eset(equilires(A, b, variant='auto', sim=sim))
        rem = EA - P
        S = eset(struct_jaccard_prune(A, len(rem), sim=sim)); rem_s = EA - S
        rec = dict(dataset=name, idx=idx, rate=float(rate), b=b, n_edges=len(EA), n_inserted=len(ins), n_removed=len(rem),
                   base=len(ins) / len(EA),
                   prec_equ=len(rem & ins) / len(rem), rec_equ=len(rem & ins) / len(ins),
                   prec_sjac=len(rem_s & ins) / len(rem_s), rec_sjac=len(rem_s & ins) / len(ins),
                   inter_removed_equ=1 - homo(rem, y), inter_removed_sjac=1 - homo(rem_s, y),
                   h_clean=homo(C, y), h_att=homo(EA, y), h_equ=homo(P, y), h_sjac=homo(S, y),
                   beta_clean=beta(C, n), beta_att=beta(EA, n), beta_equ=beta(P, n), beta_sjac=beta(S, n))
        with open(OUT, 'a') as f:
            f.write(json.dumps(rec) + '\n')
        print(f"{name:9s} idx={idx} {rate}: inserted {100*rec['base']:.1f}% of edges | removed {len(rem)} | adv. share of removed: equ {100*rec['prec_equ']:.1f}% sjac {100*rec['prec_sjac']:.1f}% | "
              f"recall equ {100*rec['rec_equ']:.1f}% sjac {100*rec['rec_sjac']:.1f}% | inter-class share of removed equ {100*rec['inter_removed_equ']:.1f}% sjac {100*rec['inter_removed_sjac']:.1f}% | "
              f"homophily clean {rec['h_clean']:.3f} att {rec['h_att']:.3f} equ {rec['h_equ']:.3f} sjac {rec['h_sjac']:.3f}", flush=True)
