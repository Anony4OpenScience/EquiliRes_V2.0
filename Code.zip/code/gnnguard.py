"""GNNGuard (Zhang & Zitnik, NeurIPS 2020) - GPU port of the official GCN variant
(github.com/mims-harvard/GNNGuard, defense/gcn.py, attention=True, drop=False, no memory).

Per layer: cosine similarity of endpoint representations on every edge, prune sim < 0.1,
row-L1-normalise, add self weight 1/(deg+1), exponentiate, then a PyG GCNConv. Layer 2 only re-scores the edges
kept by layer 1 (official forward(): adj = att_coef(x, adj); adj_2 = att_coef(h, adj)).
FIX 2026-11-12: the first port re-scored every input edge in layer 2 (carry=False), which let edges pruned in layer 1
come back; all GNNGuard results before 2026-11-12 used it (archived in results/archive_gnnguard_oldport_20261112/).
Hyper-parameters follow the official code (hidden 16, dropout 0.5, lr 0.01, wd 0);
model selection uses the validation set exactly like the official `_train_with_val`.
"""
from copy import deepcopy
import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import scatter


class GNNGuardGCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout=0.5, threshold=0.1, carry=True):
        super().__init__()
        self.gc1 = GCNConv(nfeat, nhid, bias=True)
        self.gc2 = GCNConv(nhid, nclass, bias=True)
        self.dropout = dropout
        self.threshold = threshold
        # carry=True: layer 2 scores only the edges kept by layer 1, as in the official forward()
        # (adj = att_coef(x, adj); adj_2 = att_coef(h, adj)); carry=False re-scores every input edge (old port)
        self.carry = carry

    @torch.no_grad()
    def att_coef(self, x, edge_index, n):
        row, col = edge_index
        xn = F.normalize(x, p=2, dim=1)
        sim = (xn[row] * xn[col]).sum(1)
        keep = (sim >= self.threshold) & (row != col)
        r, c, s = row[keep], col[keep], sim[keep]
        rowsum = scatter(s, r, dim=0, dim_size=n, reduce='sum')
        s = s / rowsum[r]
        deg = scatter(torch.ones_like(s), r, dim=0, dim_size=n, reduce='sum')
        loop = torch.arange(n, device=x.device)
        ei = torch.cat([torch.stack([r, c]), torch.stack([loop, loop])], 1)
        w = torch.exp(torch.cat([s, 1.0 / (deg + 1.0)]))
        return ei, w

    def forward(self, x, edge_index, sim_x=None):
        n = x.shape[0]
        ei, w = self.att_coef(x if sim_x is None else sim_x, edge_index, n)   # sim_x: structural variant (v12)
        x = F.relu(self.gc1(x, ei, edge_weight=w))
        ei, w = self.att_coef(x, ei if self.carry else edge_index, n)
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, ei, edge_weight=w)
        return F.log_softmax(x, dim=1)


def run_gnnguard(features, adj, labels, idx_train, idx_val, idx_test, seed, device,
                 epochs=200, lr=0.01, weight_decay=0.0, hidden=16, carry=True, struct=False):
    """struct=True (v12, no node features): the layer-1 cosine similarity is computed on the rows of A + I (closed neighbourhoods)
    instead of the node features, which are the identity matrix in this setting (all cosines 0, every edge would be pruned)."""
    from rebut_lib import set_seed
    set_seed(seed)
    X = features.toarray() if sp.issparse(features) else np.asarray(features)
    X = torch.tensor(X, dtype=torch.float32, device=device)
    A = sp.coo_matrix(adj)
    A = sp.coo_matrix(A + sp.eye(A.shape[0]))  # official code adds self loops before att_coef
    ei = torch.tensor(np.vstack([A.row, A.col]), dtype=torch.long, device=device)
    y = torch.tensor(labels, dtype=torch.long, device=device)
    Sx = torch.tensor(A.toarray(), dtype=torch.float32, device=device) if struct else None
    model = GNNGuardGCN(X.shape[1], hidden, int(labels.max()) + 1, carry=carry).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    best_loss, best_acc, weights = 1e9, -1, None
    for _ in range(epochs):
        model.train()
        opt.zero_grad()
        out = model(X, ei, Sx)
        F.nll_loss(out[idx_train], y[idx_train]).backward()
        opt.step()
        model.eval()
        with torch.no_grad():
            loss_val = F.nll_loss(out[idx_val], y[idx_val]).item()
            acc_val = (out[idx_val].argmax(1) == y[idx_val]).float().mean().item()
        if loss_val < best_loss:
            best_loss, weights = loss_val, deepcopy(model.state_dict())
        if acc_val > best_acc:
            best_acc, weights = acc_val, deepcopy(model.state_dict())
    model.load_state_dict(weights)
    model.eval()
    with torch.no_grad():
        out = model(X, ei, Sx)
    return dict(acc=float((out[idx_test].argmax(1) == y[idx_test]).float().mean().item()), val=best_acc)
