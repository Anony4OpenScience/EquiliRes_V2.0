"""RUNG (Hou et al., NeurIPS 2024) using the bundled model implementation in `ext/RUNG/`.

Official defaults: RUNG(D, C, [64], MCP(gamma=6.0), lam_hat=0.9), lr 5e-2, wd 5e-4,
300 epochs, row-normalised features. Model selection on the validation set (best val acc),
the same protocol as for every other method in our tables.
"""
import os
import sys
from copy import deepcopy
import numpy as np
import scipy.sparse as sp
import torch
import torch.nn.functional as F

RUNG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'ext', 'RUNG'))


def _import_rung():
    if RUNG_ROOT not in sys.path:
        sys.path.insert(0, RUNG_ROOT)
    from model.rung import RUNG
    from model.att_func import get_mcp_att_func
    return RUNG, get_mcp_att_func


def run_rung(features, adj, labels, idx_train, idx_val, idx_test, seed, device,
             gamma=6.0, lam_hat=0.9, lr=5e-2, weight_decay=5e-4, epochs=300):
    from rebut_lib import set_seed
    RUNG, get_mcp_att_func = _import_rung()
    set_seed(seed)
    X = sp.csr_matrix(features).astype(np.float64)
    rs = np.asarray(X.sum(1)).ravel()
    rs[rs == 0] = 1
    X = sp.diags(1.0 / rs) @ X
    X = torch.tensor(X.toarray(), dtype=torch.float32, device=device)
    A = adj.toarray() if sp.issparse(adj) else np.asarray(adj)
    A = torch.tensor(A, dtype=torch.float32, device=device)
    y = torch.tensor(labels, dtype=torch.long, device=device)
    model = RUNG(X.shape[1], int(labels.max()) + 1, [64], get_mcp_att_func(gamma), lam_hat).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    best_val, weights = -1, None
    for _ in range(epochs):
        model.train()
        opt.zero_grad()
        F.cross_entropy(model(A, X)[idx_train], y[idx_train]).backward()
        opt.step()
        model.eval()
        with torch.no_grad():
            pred = model(A, X).argmax(1)
            val = (pred[idx_val] == y[idx_val]).float().mean().item()
        if val > best_val:
            best_val, weights = val, deepcopy(model.state_dict())
    model.load_state_dict(weights)
    model.eval()
    with torch.no_grad():
        pred = model(A, X).argmax(1)
    return dict(acc=float((pred[idx_test] == y[idx_test]).float().mean().item()), val=best_val)
