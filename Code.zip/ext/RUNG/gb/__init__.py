"""Minimal namespace for RUNG's included model adapter."""
