Third-party code retained for review:

- `RUNG/`: the model and required support modules from the public RUNG implementation.
- `goodat_sep/`: supporting GOOD-AT source files associated with archived run logs. The authors’ original GOOD-AT run driver is not included in this package.

Please consult the included license files and upstream publications before reuse.
