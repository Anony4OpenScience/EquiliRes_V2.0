GOOD-AT utils.py as of 2025-09-23 for the detector training: PGD attacks the pseudo-labels of idx_test
(the version used for the paper's GOOD-AT / Ours+GOOD-AT numbers, Cursor history 147dfa5e/4f921f04 qTRf.py);
defenses/GOOD-AT/utils.py was changed to idx_train later (2025-11-12), which removes only ~half the edges.
Everything else is the current utils.py (binarised, no-self-loop clean adjacency). model/ -> defenses/GOOD-AT/model.
